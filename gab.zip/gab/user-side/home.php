<?php
$page_title = "QuinStyle - Home";
session_start();

if (isset($_SESSION['account'])) {
    if ($_SESSION['account']['is_staff']) {
        header('location: ../admin/dashboard.php');
        exit;
    }
} else {
    header('location: index.php');
}

require_once '../includes/_head.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuinStyle</title>
    <link rel="stylesheet" href="../css/index.css">
</head>
<body id="home">
    <div class="wrapper">
        <!-- Include Navigation Bar -->
        <?php require_once '../includes/_topnav.php'; ?>

        <!-- Main Content -->
        <div class="content-page px-3">
            <!-- Add your dynamic content or hero section here -->
            <section class="hero">
                <div class="hero-content">
                    <h1>Welcome to Our Website!</h1>
                    <p>Your one-stop solution for everything.</p>
                    <a href="../shop/shop.php" class="btn">Shop Now</a>
                </div>
            </section>
        </div>
    </div>

    <!-- Include Footer -->
    <?php require_once '../includes/_footer.php'; ?>
    <?php require_once '../includes/_footer-script.php'; ?>
</body>
</html>
