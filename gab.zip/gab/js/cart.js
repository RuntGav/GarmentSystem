$(document).ready(function () {
// JavaScript to handle checkbox state change and AJAX request
$(".purchase-cart").on("click", function (e) {
    e.preventDefault(); // Prevent default behavior
    modalPurchaseCart(this.dataset.id); // Call function to edit product
  });

  $(".delete-cart").on("click", function (e) {
    e.preventDefault(); // Prevent default behavior
    deletingCart(this.dataset.id); // Call function to edit product
  });

  function modalPurchaseCart(cart_id) {
    $.ajax({
      type: "GET",
      url: "../cart/cart-purchase.html",
      dataType: "html",
      success: function (view) {
        $(".modal-container").empty().html(view);
        $("#staticBackdropPurchase").modal("show");
        $("#staticBackdropPurchase").attr("data-id", cart_id);
  
        // Call the details fetching function
        $("#form-confirm-purchase").on("submit", function (e) {
            e.preventDefault(); // Prevent default form submission
            PurchaseCart(cart_id); // Call function to update product
          });
      },
    });
  }

function PurchaseCart(cart_id) {
    $.ajax({
        type: "POST",
        url: `../cart/cart-purchase.php?id=${cart_id}`,  // Pass cart_id in the URL only
        dataType: "json",
        success: function (response) {
            if (response.status === "success") {
                $("#staticBackdropPurchase").modal("hide");
                $("form")[0].reset();
            } else {
                console.error(response.message);
            }
        },
        error: function () {
            console.error("Failed to buy the item. Please try again.");
        }
    });
}

//To show modal
function deletingCart(cart_id) {
    $.ajax({
        type: "GET", // Use GET request
        url: "../cart/delete-cart.html", // URL to get product data
        dataType: "html", // Expect HTML response
        success: function (view) {
            $(".modal-container").empty().html(view); // Load the modal view
            $("#staticBackdropDelete").modal("show"); // Show the modal
            $("#staticBackdropDelete").attr("data-id", cart_id);

            // Set the cart_id in the hidden input
            $("#cart-id").val(cart_id);

            // Event listener for the form submission
            $("#form-delete-cart").on("submit", function (e) {
                e.preventDefault(); // Prevent default form submission
                deleteCart(cart_id); // Call the function to delete the cart item
            });
        },
    });
}

// Function to delete account
function deleteCart(cart_id) {
    $.ajax({
        type: "POST", // Use POST request
        url: "../cart/delete-cart-item.php", // URL of the PHP script
        data: { cart_id: cart_id }, // Send cart_id to the PHP script
        dataType: "json", // Expect a JSON response
        success: function (response) {
            if (response.status === "success") {
                $("#staticBackdropDelete").modal("hide"); // Close the modal
                $("form")[0].reset(); // Reset the form
                // Optionally, refresh the page or update the UI
                window.location.href = 'cart.php'; // Redirect to cart page
            } else {
                alert(response.message); // Show failure message
            }
        },
        error: function () {
            alert("An error occurred while deleting the item.");
        }
    });
}



});