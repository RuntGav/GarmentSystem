-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 29, 2024 at 04:22 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quinstyle`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--


CREATE TABLE `account` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('customer','admin','staff') NOT NULL DEFAULT 'customer',
  `is_staff` tinyint(1) NOT NULL DEFAULT 0,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account`
--

CREATE TABLE stocks (
    `stocks_id` INT(11) PRIMARY KEY AUTO_INCREMENT,
    `product_id` INT(11) NOT NULL,
    `quantity` INT(11) NOT NULL,
    `status` VARCHAR(100) NOT NULL,
    `reason` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT fk_product FOREIGN KEY (product_id) REFERENCES product(product_id)
);

INSERT INTO `account` (`id`, `first_name`, `last_name`, `username`, `password`, `role`, `is_staff`, `is_admin`) VALUES
(1, 'gorb', 'ulgasan', 'gorb', '$2y$10$r/eOm6rKBUrUxDuvNOy3eOQ0b6YZgyrEAoZ2MBGOf62YpfLPMmn62', 'customer', 0, 0),
(2, 'admin', 'admin', 'admin', '$2y$10$O2IbjaLJYzxaUJWsaVRQxeK3QoL28XrdJXysQH9EBEXK6rd7hvDRC', 'admin', 1, 1),
(3, 'solus', 'luna', 'solus', '$2y$10$8ymO.ZjHlPC7t22EvWwkqOQOw2hYldQJyxjLDqgGEVl/6FyCaXbg2', 'customer', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `custom_uniform_id` int(11) DEFAULT NULL,
  `account_id` int(11) NOT NULL,
  `quantity` int(12) NOT NULL,
  `status` enum('pending','paid') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `product_id`, `custom_uniform_id`, `account_id`, `quantity`, `status`, `created_at`, `updated_at`) VALUES
(7, NULL, 2, 1, 3, 'pending', '2024-11-27 16:28:03', '2024-11-27 16:28:03');

-- --------------------------------------------------------

--
-- Table structure for table `cart_bin`
--

CREATE TABLE `cart_bin` (
  `cart_bin_id` int(11) NOT NULL,
  `cart_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `custom_uniform_id` int(11) DEFAULT NULL,
  `account_id` int(11) NOT NULL,
  `quantity` int(12) NOT NULL,
  `status` enum('pending','paid') DEFAULT 'pending',
  `deleted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart_bin`
--

INSERT INTO `cart_bin` (`cart_bin_id`, `cart_id`, `product_id`, `custom_uniform_id`, `account_id`, `quantity`, `status`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 9, NULL, 4, 1, 1, 'pending', '2024-11-29 03:16:31', '2024-11-28 07:05:18', '2024-11-28 07:05:18');

-- --------------------------------------------------------

--
-- Table structure for table `consultations`
--

CREATE TABLE `consultations` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact_number` varchar(15) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `consultations`
--

INSERT INTO `consultations` (`id`, `customer_id`, `email`, `contact_number`, `message`, `created_at`) VALUES
(1, 1, 'gyjpretty@gmail.com', '09155581416', 'nothing', '2024-11-29 02:34:35'),
(2, 1, 'mdark6754@gmail.com', '09155581416', 'no way', '2024-11-29 02:44:46');

-- --------------------------------------------------------

--
-- Table structure for table `custom_uniform`
--

CREATE TABLE `custom_uniform` (
  `custom_uniform_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  `chest_measurement` decimal(5,2) DEFAULT NULL,
  `waist_measurement` decimal(5,2) DEFAULT NULL,
  `hip_measurement` decimal(5,2) DEFAULT NULL,
  `shoulder_width` decimal(5,2) DEFAULT NULL,
  `sleeve_length` decimal(5,2) DEFAULT NULL,
  `pant_length` decimal(5,2) DEFAULT NULL,
  `custom_features` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `production_time_days` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `custom_uniform`
--

INSERT INTO `custom_uniform` (`custom_uniform_id`, `name`, `gender`, `chest_measurement`, `waist_measurement`, `hip_measurement`, `shoulder_width`, `sleeve_length`, `pant_length`, `custom_features`, `price`, `production_time_days`, `created_at`, `updated_at`) VALUES
(1, 'PE', 'male', 35.00, 30.00, 37.00, 15.00, 25.00, 39.00, 'nothing', NULL, NULL, '2024-11-27 15:29:16', '2024-11-27 15:29:16'),
(2, 'PE', 'female', 36.00, 31.00, 30.00, 16.00, 25.00, 39.00, 'nothing', 99.00, NULL, '2024-11-27 16:28:03', '2024-11-27 16:35:23'),
(3, 'uniform', 'male', 33.00, 29.00, 35.00, 13.00, 22.00, 37.00, 'no', NULL, NULL, '2024-11-27 16:33:07', '2024-11-27 16:33:07'),
(4, 'PE', 'male', 36.00, 31.00, 31.00, 16.00, 25.00, 39.00, 'nothing', NULL, NULL, '2024-11-28 07:05:18', '2024-11-28 07:05:18');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `gender` enum('male','female') NOT NULL,
  `size` enum('small','medium','large') NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `name`, `description`, `gender`, `size`, `price`, `stock`, `created_at`, `updated_at`) VALUES
(1, 'uniform', 'Uniform for Male Students', 'male', 'small', 20.00, 15, '2024-11-25 13:45:33', '2024-11-25 13:45:33'),
(2, 'uniform', 'Uniform for Male Students', 'male', 'medium', 20.00, 20, '2024-11-25 13:45:33', '2024-11-25 13:45:33'),
(3, 'uniform', 'Uniform for Male Students', 'male', 'large', 20.00, 10, '2024-11-25 13:45:33', '2024-11-25 13:45:33'),
(4, 'uniform', 'Uniform for Female Students', 'female', 'small', 20.00, 25, '2024-11-25 13:45:33', '2024-11-25 13:45:33'),
(5, 'uniform', 'Uniform for Female Students', 'female', 'medium', 20.00, 30, '2024-11-25 13:45:33', '2024-11-25 13:45:33'),
(6, 'uniform', 'Uniform for Female Students', 'female', 'large', 20.00, 15, '2024-11-25 13:45:33', '2024-11-25 13:45:33'),
(7, 'pe', 'PE Clothing for Male Students', 'male', 'small', 12.00, 35, '2024-11-25 13:45:33', '2024-11-25 13:45:33'),
(8, 'pe', 'PE Clothing for Male Students', 'male', 'medium', 12.00, 40, '2024-11-25 13:45:33', '2024-11-25 13:45:33'),
(9, 'pe', 'PE Clothing for Male Students', 'male', 'large', 12.00, 25, '2024-11-25 13:45:33', '2024-11-25 13:45:33'),
(10, 'pe', 'PE Clothing for Female Students', 'female', 'small', 12.00, 40, '2024-11-25 13:45:33', '2024-11-25 13:45:33'),
(11, 'pe', 'PE Clothing for Female Students', 'female', 'medium', 12.00, 35, '2024-11-25 13:45:33', '2024-11-25 13:45:33'),
(12, 'pe', 'PE Clothing for Female Students', 'female', 'large', 12.00, 30, '2024-11-25 13:45:33', '2024-11-25 13:45:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `fk_product` (`product_id`),
  ADD KEY `fk_custom_uniform` (`custom_uniform_id`),
  ADD KEY `fk_account` (`account_id`);

--
-- Indexes for table `cart_bin`
--
ALTER TABLE `cart_bin`
  ADD PRIMARY KEY (`cart_bin_id`),
  ADD KEY `fk_cart_bin_product` (`product_id`),
  ADD KEY `fk_cart_bin_custom_uniform` (`custom_uniform_id`),
  ADD KEY `fk_cart_bin_account` (`account_id`);

--
-- Indexes for table `consultations`
--
ALTER TABLE `consultations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `custom_uniform`
--
ALTER TABLE `custom_uniform`
  ADD PRIMARY KEY (`custom_uniform_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cart_bin`
--
ALTER TABLE `cart_bin`
  MODIFY `cart_bin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `consultations`
--
ALTER TABLE `consultations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `custom_uniform`
--
ALTER TABLE `custom_uniform`
  MODIFY `custom_uniform_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `fk_account` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_custom_uniform` FOREIGN KEY (`custom_uniform_id`) REFERENCES `custom_uniform` (`custom_uniform_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_product` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON DELETE SET NULL;

--
-- Constraints for table `cart_bin`
--
ALTER TABLE `cart_bin`
  ADD CONSTRAINT `fk_cart_bin_account` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_cart_bin_custom_uniform` FOREIGN KEY (`custom_uniform_id`) REFERENCES `custom_uniform` (`custom_uniform_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_cart_bin_product` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON DELETE SET NULL;

--
-- Constraints for table `consultations`
--
ALTER TABLE `consultations`
  ADD CONSTRAINT `consultations_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `account` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
