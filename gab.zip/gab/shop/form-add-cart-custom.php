<?php
$page_title = "QuinStyle - Order";
session_start();

// Retrieve the image from the query parameter, default to 'img/custom_uniform.webp' if not set

if (isset($_SESSION['account'])) {
    if ($_SESSION['account']['is_staff']) {
        header('location: ../admin/dashboard.php');
        exit;
    }
} else {
    header('location: index.php');
}

$customer_id = $_SESSION['account']['id'] ?? null;

require_once '../includes/_head.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Customize Your Uniform</title>
  <link rel="stylesheet" href="../css/form-order.css">
</head>
<body id="home">
  <!-- Navbar -->
  <?php require_once '../includes/_topnav.php'; ?>

  <!-- Custom Uniform Section -->
    <!-- Size Measurement Prompt -->

    <!-- Form -->
    <div class="form-container">
        <form action="../cart/add-to-cart-custom.php" method="POST">
            <h2>Customize Your Uniform/PE</h2>
            <br>    <div class="size-prompt">
        <p>Don't know your actual size? <strong>Go to a garment shop to measure your sizes.</strong></p>
    </div>

            <!-- Hidden input for customer ID -->
            <input type="hidden" name="customer_id" value="<?= htmlspecialchars($customer_id) ?>">

            <label for="name">Uniform Type</label>
            <input type="text" id="name" name="name" placeholder="e.g., Custom School Uniform/Custom PE Uniform" required>

            <label for="gender">Gender</label>
            <select id="gender" name="gender" required>
                <option value="male">Male</option>
                <option value="female">Female</option>
            </select>

            <label for="chest_measurement">Chest Measurement (in inches)</label>
            <input type="number" id="chest_measurement" name="chest_measurement" step="0.01" min="0" placeholder="e.g., 36.5">

            <label for="waist_measurement">Waist Measurement (in inches)</label>
            <input type="number" id="waist_measurement" name="waist_measurement" step="0.01" min="0" placeholder="e.g., 30.0">

            <label for="hip_measurement">Hip Measurement (in inches)</label>
            <input type="number" id="hip_measurement" name="hip_measurement" step="0.01" min="0" placeholder="e.g., 38.0">

            <label for="shoulder_width">Shoulder Width (in inches)</label>
            <input type="number" id="shoulder_width" name="shoulder_width" step="0.01" min="0" placeholder="e.g., 15.5">

            <label for="sleeve_length">Sleeve Length (in inches)</label>
            <input type="number" id="sleeve_length" name="sleeve_length" step="0.01" min="0" placeholder="e.g., 24.0">

            <label for="pant_length">Pant Length (in inches)</label>
            <input type="number" id="pant_length" name="pant_length" step="0.01" min="0" placeholder="e.g., 40.0">

            <label for="custom_features">Custom Features</label>
            <textarea id="custom_features" name="custom_features" rows="4" placeholder="e.g., Embroidery, School Logo"></textarea>

            <label for="quantity">Quantity</label>
            <input type="number" id="quantity" name="quantity" min="1" value="1" required>

            <button type="submit" class="btn btn-primary">Add to Cart</button>
        </form>
    </div>


  <!-- Include Footer -->
  <?php require_once '../includes/_footer.php'; ?>
  <?php require_once '../includes/_footer-script.php'; ?>
</body>
</html>
