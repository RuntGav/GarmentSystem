<footer class="footer">
    <p> nginang footer to.</p>
</footer>
