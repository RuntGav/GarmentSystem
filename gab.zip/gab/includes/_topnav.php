<nav class="navbar">
    <div class="logo">QuinStyle</div>
    <div class="nav-links">
    <a href="../user-side/home.php">Home</a>
        <a href="../cart/cart.php">My Cart</a>
        <a href="../account/logout.php">Logout</a>
    </div>
</nav>
