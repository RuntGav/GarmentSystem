<?php
require_once '../classes/cart-bin.class.php';
require_once('../tools/functions.php'); // Include the functions file with the clean_input function

// Check if the request method is POST and the cart_bin_id is provided
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cart_bin_id']) && !empty($_POST['cart_bin_id'])) {
    // Sanitize the cart_bin_id using clean_input function
    $cartBinId = clean_input($_POST['cart_bin_id']);

    // Validate cart_bin_id to ensure it's numeric
    if (!is_numeric($cartBinId)) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Invalid Cart Bin ID.'
        ]);
        exit;
    }

    // Instantiate the CartBin class
    $cartBinObj = new CartBin();

    // Call the restore method to restore the cart bin
    if ($cartBinObj->restore($cartBinId)) {
        // Send a success response
        echo json_encode([
            'status' => 'success',
            'message' => 'Cart bin restored successfully.'
        ]);
    } else {
        // Send an error response if the restore operation fails
        http_response_code(500);
        echo json_encode([
            'status' => 'error',
            'message' => 'Failed to restore the cart bin.'
        ]);
    }
} else {
    // Handle invalid requests (either no POST or cart_bin_id not provided)
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request. Cart bin ID is required.'
    ]);
}
?>
