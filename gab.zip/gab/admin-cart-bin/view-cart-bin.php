<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">Cart Bin</h4>
            </div>
        </div>
    </div>
    <div class="modal-container"></div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <?php
                        require_once '../classes/cart-bin.class.php';
                        session_start();
                        $cartBinObj = new CartBin();
                        ?>
                        <div class="d-flex justify-content-center align-items-center">
                            <form class="d-flex me-2">
                                <div class="input-group w-100">
                                    <input type="text" class="form-control form-control-light" id="custom-search" placeholder="Search cart bin...">
                                    <span class="input-group-text bg-primary border-primary text-white">
                                        <i class="bi bi-search"></i>
                                    </span>
                                </div>
                            </form>
                            <div class="d-flex align-items-center me-3">
                                <label for="uni-filter" class="me-2">Category</label>
                                <select id="uni-filter" class="form-select">
                                    <option value="">All</option>
                                    <option value="uniform">Uniform</option>
                                    <option value="pe">PE</option>
                                </select>
                            </div>
                        </div>
                        <div class="page-title-right d-flex align-items-center">
                            <button id="refresh-cart-bin" class="btn btn-primary">Refresh</button>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table id="table-cart-bin" class="table table-centered table-nowrap mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="text-start">No.</th>
                                    <th>Customer Name</th> <!-- Added Customer Name column -->
                                    <th>Cart ID</th>
                                    <th>Product/Custom Uniform</th>
                                    <th>Quantity</th>
                                    <th>Status</th>
                                    <th>Deleted At</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i = 1;
                                $cartBinItems = $cartBinObj->showAll();

                                foreach ($cartBinItems as $item) {
                                    ?>
                                    <tr>
                                        <td class="text-start"><?= $i ?></td>
                                        <td><?= $item['customer_name'] ?></td> <!-- Display customer name -->
                                        <td><?= $item['cart_id'] ?></td>
                                        <td><?= $item['product_name'] ?: $item['custom_uniform_name'] ?></td>
                                        <td><?= $item['quantity'] ?></td>
                                        <td><?= ucfirst($item['status']) ?></td>
                                        <td><?= $item['deleted_at'] ?></td>
                                        <td class="text-nowrap">
                                            <a href="#" class="btn btn-sm btn-outline-primary restore-bin" data-id="<?= $item['cart_bin_id'] ?>">Restore</a>
                                            <a href="#" class="btn btn-sm btn-outline-danger delete-bin" data-id="<?= $item['cart_bin_id'] ?>">Delete</a>
                                        </td>
                                    </tr>
                                    <?php
                                    $i++;
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
