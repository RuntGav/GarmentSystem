<?php
session_start(); // Start the session
require_once '../classes/cart-bin.class.php';

$cartbinObj = new CartBin();

if (isset($_POST['cart_bin_id']) && !empty($_POST['cart_bin_id'])) {
    $cart_bin_id = $_POST['cart_bin_id'];

    // Perform the deletion
    $isDeleted = $cartbinObj->deletePermanently($cart_bin_id);

    if ($isDeleted) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Cart Bin ID is required']);
}
