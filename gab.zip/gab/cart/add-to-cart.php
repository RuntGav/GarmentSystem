<?php
session_start();
require_once '../tools/functions.php';
require_once '../classes/cart.class.php';

$product_type = $gender = $size = $quantity = '';
$product_typeErr = $genderErr = $sizeErr = $quantityErr = '';

// Get the cart object
$cartObj = new Cart();

// Default response array
$response = ['status' => 'success', 'errors' => []];

// Check if the user is logged in and get the customer_id from session

if (isset($_SESSION['account'])) {
    $customer_id = $_SESSION['account']['id']; // Get the customer_id from the session
} else {
    $response['status'] = 'error';
    $response['errors']['customer_idErr'] = 'You must be logged in to add items to the cart.';
    echo json_encode($response);
    exit;
}

// Proceed with the cart addition if the user is logged in
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Clean and validate inputs
    $product_type = clean_input($_POST['uniform_type']);
    $gender = clean_input($_POST['gender']);
    $size = clean_input($_POST['size']);
    $quantity = clean_input($_POST['quantity']);

    // Validate product_type
    if (empty($product_type)) {
        $product_typeErr = 'Product type is required.';
    }

    // Validate gender
    if (empty($gender)) {
        $genderErr = 'Gender is required.';
    } elseif (!in_array($gender, ['male', 'female'])) {
        $genderErr = 'Invalid gender value.';
    }

    // Validate size
    if (empty($size)) {
        $sizeErr = 'Size is required.';
    } elseif (!in_array($size, ['small', 'medium', 'large'])) {
        $sizeErr = 'Invalid size value.';
    }

    // Validate quantity
    if (empty($quantity)) {
        $quantityErr = 'Quantity is required.';
    } elseif (!is_numeric($quantity) || $quantity <= 0) {
        $quantityErr = 'Quantity must be a positive number.';
    }

    // If there are errors, send back the error responses
    if ($product_typeErr || $genderErr || $sizeErr || $quantityErr) {
        $response['status'] = 'error';
        $response['product_typeErr'] = $product_typeErr;
        $response['genderErr'] = $genderErr;
        $response['sizeErr'] = $sizeErr;
        $response['quantityErr'] = $quantityErr;
    } else {
        // Check if the product exists
        $product_id = $cartObj->getProductId($product_type, $gender, $size);
        if (!$product_id) {
            $response['status'] = 'error';
            $response['product_typeErr'] = 'Product not found.';
        } else {
            // Add the item to the cart
            $cartObj->customer_id = $customer_id;
            $cartObj->product_id = $product_id;
            $cartObj->quantity = $quantity;

            if ($cartObj->addToCart()) {
                $response['status'] = 'success'; // Success response
            } else {
                $response['status'] = 'error';
                $response['quantityErr'] = 'Failed to add the item to cart.';
            }
        }
    }

    // Return response as JSON
    echo json_encode($response);
}
?>
