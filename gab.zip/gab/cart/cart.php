<?php
$page_title = "QuinStyle - My Cart";
session_start();

// Include the database connection and cart class
require_once '../classes/database.class.php';
require_once '../classes/cart.class.php';
require_once '../classes/custom-item.class.php';  // Include the CustomItem class
require_once '../classes/account.class.php'; // Include the Account class

if (isset($_GET['action'], $_GET['cart_id']) && $_GET['action'] === 'delete') {
    $cart_id = intval($_GET['cart_id']);
    $cart = new Cart();

    if ($cart->deleteCartItem($cart_id)) {
        echo "<script>alert('Item moved to cart bin successfully.'); window.location.href='cart.php';</script>";
    } else {
        echo "<script>alert('Failed to delete item.'); window.location.href='cart.php';</script>";
    }
}


// Check if the customer is logged in
if (!isset($_SESSION['account'])) {
    header('location: index.php'); // Redirect to login page if not logged in
    exit;
} 

// Check if the logged-in user is a staff member, and redirect if necessary
if ($_SESSION['account']['is_staff']) {
    header('location: ../admin/dashboard.php');
    exit;
}



$customer_id = $_SESSION['account']['id'] ?? null;

// Check if a valid customer_id was returned
if ($customer_id === null) {
    echo "<script>alert('Error: Customer ID not found.'); window.location.href='index.php';</script>";
    exit;
}

$cart = new Cart();
$cart->customer_id = $customer_id;

// Fetch cart items
$cartItems = $cart->showCart(); // Fetch regular cart items

// Create an instance of CustomItem class to fetch custom items
$customItem = new CustomItem();
$customItem->customer_id = $customer_id;
$customItems = $customItem->showCustomItems(); // Fetch custom uniform items

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link href="../vendor/bootstrap-5.3.3/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/cart.css" rel="stylesheet">
</head>

<body id="home">
    <div class="wrapper">
        <!-- Include Navigation Bar -->
        <?php require_once '../includes/_topnav.php'; ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <h4 class="page-title">Your Cart</h4>
                    </div>
                </div>
            </div>
            <div class="modal-container"></div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <form method="post">
                                <div class="table-responsive">
                                    <table id="table-cart" class="table table-centered table-nowrap mb-0">
                                        <thead class="table-light">
                                            <tr>
                                                <th><input type="checkbox" id="selectAll"></th>
                                                <th class="text-start">No.</th>
                                                <th>Product Name</th>
                                                <th>Gender</th>
                                                <th>Size</th>
                                                <th>Quantity</th>
                                                <th>Price</th>
                                                <th>Total Price</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if ($cartItems || $customItems): ?>
                                                <?php
                                                $i = 1;
                                                $grandTotal = 0;
                                                // Loop through regular cart items
                                                foreach ($cartItems as $item):
                                                    $totalPrice = $item['quantity'] * $item['Price'];
                                                    $isPending = $item['status'] === 'pending';
                                                ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="checkedItems[]" value="<?= $item['cart_id'] ?>" 
                                                                class="itemCheckbox" <?= $isPending ? '' : 'disabled' ?> 
                                                                data-price="<?= $totalPrice ?>">
                                                        </td>
                                                        <td class="text-start"><?= $i ?></td>
                                                        <td><?= htmlspecialchars($item['Product_Name']) ?></td>
                                                        <td><?= htmlspecialchars($item['gender']) ?></td>
                                                        <td><?= htmlspecialchars($item['size']) ?></td>
                                                        <td><?= htmlspecialchars($item['quantity']) ?></td>
                                                        <td><?= '$' . number_format($item['Price'], 2) ?></td>
                                                        <td><?= '$' . number_format($totalPrice, 2) ?></td>
                                                        <td><?= htmlspecialchars($item['status'] ?? 'Unknown') ?></td>
                                                        <td>
                                                        <a href="#" class="btn btn-sm btn-outline-primary me-1 purchase-cart" data-id="<?= $item['cart_id'] ?>">Purchase</a>
                                                        <a href="" class="btn btn-sm btn-outline-danger me-1 delete-cart" data-id="<?= $item['cart_id'] ?>">Delete</a>
                                                        </td>
                                                    </tr>
                                                <?php
                                                    $i++;
                                                endforeach;

                                                // Loop through custom cart items
                                                foreach ($customItems as $item):
                                                    $totalPrice = $item['quantity'] * $item['price'];
                                                    $isPending = $item['status'] === 'pending';
                                                ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="checkedItems[]" value="<?= $item['cart_id'] ?>" 
                                                                class="itemCheckbox" <?= $isPending ? '' : 'disabled' ?> 
                                                                data-price="<?= $totalPrice ?>">
                                                        </td>
                                                        <td class="text-start"><?= $i ?></td>
                                                        <td><?= htmlspecialchars($item['Custom_Name']) ?></td>
                                                        <td><?= htmlspecialchars($item['gender']) ?></td>
                                                        <td>Custom Made</td> <!-- For custom uniforms -->
                                                        <td><?= htmlspecialchars($item['quantity']) ?></td>
                                                        <td><?= '$' . number_format($item['price'], 2) ?></td>
                                                        <td><?= '$' . number_format($totalPrice, 2) ?></td>
                                                        <td><?= htmlspecialchars($item['status'] ?? 'Unknown') ?></td>
                                                        <td>
                                                        <a href="#" class="btn btn-sm btn-outline-primary me-1 purchase-cart" data-id="<?= $item['cart_id'] ?>">Purchase</a>
                                                        <a href="" class="btn btn-sm btn-outline-danger me-1 delete-cart" data-id="<?= $item['cart_id'] ?>">Delete</a>
                                                        </td>
                                                    </tr>
                                                <?php
                                                    $i++;
                                                endforeach;
                                                ?>
                                            <?php else: ?>
                                                <tr>
                                                    <td colspan="10" class="text-center">Your cart is empty.</td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Include Footer -->
    <?php require_once ('../includes/_footer.php'); ?>
    <?php require_once ('../includes/_footer-script.php'); ?>
    <script src="../js/cart.js"></script>
</body>

</html>
