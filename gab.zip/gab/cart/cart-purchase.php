<?php
require_once '../tools/functions.php'; // Optional: If you need a clean_input function
require_once '../classes/database.class.php';
require_once '../classes/cart.class.php';

$cart_id = $_GET['id'] ?? null;
if (!$cart_id) {
    echo json_encode(['status' => 'error', 'message' => 'No cart ID provided']);
    exit;
}

$cartObj = new Cart();

if ($cart_id) {
    $result = $cartObj->processPurchase($cart_id);
// Process the purchase
    echo json_encode(['status' => 'success', 'message' => 'Item purchased successfully']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to process purchase']);
}

?>
