<?php

require_once '../tools/functions.php';
require_once '../classes/custom-item.class.php';

$customItemObj = new CustomItem();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Clean and validate inputs
    $customer_id = clean_input($_POST['customer_id']);
    $name = clean_input($_POST['name']);
    $gender = clean_input($_POST['gender']);
    $chest_measurement = clean_input($_POST['chest_measurement']);
    $waist_measurement = clean_input($_POST['waist_measurement']);
    $hip_measurement = clean_input($_POST['hip_measurement']);
    $shoulder_width = clean_input($_POST['shoulder_width']);
    $sleeve_length = clean_input($_POST['sleeve_length']);
    $pant_length = clean_input($_POST['pant_length']);
    $custom_features = clean_input($_POST['custom_features']);
    $quantity = clean_input($_POST['quantity']);

    // Additional validation (example)
    if (empty($customer_id) || empty($name) || empty($gender) || empty($quantity)) {
        echo "<script>alert('Validation Error: Please fill in the required fields.'); window.history.back();</script>";
        exit;
    }

    // Insert custom uniform into the database
    $custom_uniform_id = $customItemObj->createCustomUniform([
        'name' => $name,
        'gender' => $gender,
        'chest_measurement' => $chest_measurement,
        'waist_measurement' => $waist_measurement,
        'hip_measurement' => $hip_measurement,
        'shoulder_width' => $shoulder_width,
        'sleeve_length' => $sleeve_length,
        'pant_length' => $pant_length,
        'custom_features' => $custom_features,
        'price' => null, // Optional: Pass a price if applicable
        'production_time_days' => null, // Optional: Pass production time if applicable
    ]);

    if (!$custom_uniform_id) {
        echo "<script>alert('Failed to create custom uniform.'); window.history.back();</script>";
        exit;
    }

    // Add the custom uniform to the cart
    $customItemObj->customer_id = $customer_id;
    $customItemObj->custom_uniform_id = $custom_uniform_id;
    $customItemObj->quantity = $quantity;

    if ($customItemObj->addToCartCustom()) {
        echo "<script>alert('Custom item added to cart successfully!'); window.location.href='../cart/cart.php';</script>";
    } else {
        echo "<script>alert('Failed to add custom item to cart.'); window.history.back();</script>";
    }
}
