<?php

require_once 'database.class.php';
require_once 'stocks.class.php';

class Cart
{
    public $cart_id = '';
    public $customer_id = '';

    protected $db;

    function __construct()
    {
        $this->db = new Database();
    }

    public function getProductId($product_type, $gender, $size)
    {
        $sql = "SELECT product_id 
                FROM product
                WHERE name = :product_type AND gender = :gender AND size = :size LIMIT 1";
        $query = $this->db->connect()->prepare($sql);
        $query->execute([
            ':product_type' => $product_type,
            ':gender' => $gender,
            ':size' => $size,
        ]);
        $result = $query->fetch();
        return $result ? $result['product_id'] : false;
    }

    // Show all cart items for the customer
    function showCart() {
        $sql = "SELECT c.cart_id, c.product_id, c.quantity, p.name AS Product_Name, p.price AS Price, p.size, p.gender, c.status
                FROM cart c
                INNER JOIN product p ON c.product_id = p.product_id
                WHERE c.account_id = :account_id AND c.custom_uniform_id IS NULL"; // Exclude custom items
        $query = $this->db->connect()->prepare($sql);
        $query->bindParam(':account_id', $this->customer_id);
        $query->execute();
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    // Add product to cart
    function addToCart()
    {
        $sql = "INSERT INTO cart (product_id, account_id, quantity, status) 
                VALUES (:product_id, :customer_id, :quantity, 'pending')";
        $query = $this->db->connect()->prepare($sql);
        return $query->execute([
            ':product_id' => $this->product_id,
            ':customer_id' => $this->customer_id,
            ':quantity' => $this->quantity,
        ]);
    }


    // Move cart item to cart_bin and delete from cart
    function deleteCartItem($cart_id)
    {
        try {
            // Begin transaction
            $this->db->connect()->beginTransaction();

            // Retrieve the cart item details
            $sql = "SELECT * FROM cart WHERE cart_id = :cart_id";
            $query = $this->db->connect()->prepare($sql);
            $query->execute([':cart_id' => $cart_id]);
            $cartItem = $query->fetch(PDO::FETCH_ASSOC);

            if (!$cartItem) {
                throw new Exception("Cart item not found.");
            }

            // Check if the cart status is 'paid'
            if ($cartItem['status'] === 'paid') {
                // Move the cart item to the cart_bin table
                $sql = "INSERT INTO cart_bin (
                            cart_id, product_id, custom_uniform_id, account_id, quantity, status, created_at, updated_at
                        ) VALUES (
                            :cart_id, :product_id, :custom_uniform_id, :account_id, :quantity, :status, :created_at, :updated_at
                        )";
                $query = $this->db->connect()->prepare($sql);
                $query->execute([
                    ':cart_id' => $cartItem['cart_id'],
                    ':product_id' => $cartItem['product_id'],
                    ':custom_uniform_id' => $cartItem['custom_uniform_id'],
                    ':account_id' => $cartItem['account_id'],
                    ':quantity' => $cartItem['quantity'],
                    ':status' => $cartItem['status'],
                    ':created_at' => $cartItem['created_at'],
                    ':updated_at' => $cartItem['updated_at'],
                ]);
            }

            // Delete the cart item from the cart table
            $sql = "DELETE FROM cart WHERE cart_id = :cart_id";
            $query = $this->db->connect()->prepare($sql);
            $query->execute([':cart_id' => $cart_id]);

            // Commit transaction
            $this->db->connect()->commit();

            return true;
        } catch (Exception $e) {
            // Rollback transaction in case of an error
            $this->db->connect()->rollBack();
            error_log($e->getMessage());
            return false;
        }
    }

function processPurchase($cart_id)
    {
        // Step 1: Get cart item details
        $sql = "SELECT product_id, quantity FROM cart WHERE cart_id = :cart_id";
        $query = $this->db->connect()->prepare($sql);
        $query->execute([':cart_id' => $cart_id]);
        $cartItem = $query->fetch(PDO::FETCH_ASSOC);

        if (!$cartItem) {
            return false; // Cart item not found
        }

        // Step 2: Reduce stock using the Stocks class (adjust stock)
        $stocks = new Stocks(); // Instantiate Stocks class
        $product_id = $cartItem['product_id'];
        $quantity = $cartItem['quantity'];

        // Reduce stock for the purchased product
        $stocks->product_id = $product_id;
        $stocks->quantity = $quantity;
        $stocks->status = 'out'; // Assuming 'out' indicates that stock is being reduced
        $stocks->reason = 'purchase'; // Reason for stock reduction
        $stocks->add(); // Call add() method to reduce stock

        // Step 3: Mark the cart item as 'paid'
        $sql = "UPDATE cart SET status = 'paid' WHERE cart_id = :cart_id AND status = 'pending'";
        $query = $this->db->connect()->prepare($sql);
        $query->bindParam(':cart_id', $cart_id, PDO::PARAM_INT);
        
        if ($query->execute()) {
            return true; // Successfully marked as paid and reduced stock
        } else {
            return false; // Something went wrong while updating
        }
    }
}


