<?php

require_once '../classes/database.class.php'; // Adjust path as needed

class Product
{
    protected $db;

    function __construct()
    {
        $this->db = new Database();
    }

    // Fetch all products
    function showAll($keyword = '', $gender = '', $size = '')
    {
        // SQL query to select products, including stock information from the stocks table
        $sql = "SELECT p.product_id, p.name, p.description, p.gender, p.size, p.price, 
                       p.created_at, p.updated_at, 
                       SUM(IF(s.status = 'in', s.quantity, 0)) AS stock_in, 
                       SUM(IF(s.status = 'out', s.quantity, 0)) AS stock_out 
                FROM product p 
                LEFT JOIN stocks s ON p.product_id = s.product_id
                WHERE (p.name LIKE CONCAT('%', :keyword, '%') 
                OR p.description LIKE CONCAT('%', :keyword, '%')) 
                AND (p.gender LIKE CONCAT('%', :gender, '%')) 
                AND (p.size LIKE CONCAT('%', :size, '%')) 
                GROUP BY p.product_id
                ORDER BY p.name ASC;";
    
        // Prepare the query
        $query = $this->db->connect()->prepare($sql);
    
        // Bind parameters
        $query->bindParam(':keyword', $keyword);
        $query->bindParam(':gender', $gender);
        $query->bindParam(':size', $size);
    
        // Execute the query and fetch data
        $data = null;
        if ($query->execute()) {
            $data = $query->fetchAll();
        }
    
        // Return the data
        return $data;
    }

    function updatePrice()
{
    // SQL query to update the price of a specific product
    $sql = "UPDATE product SET price = :price WHERE product_id = :product_id";

    // Prepare the query
    $query = $this->db->connect()->prepare($sql);

    // Bind parameters
    $query->bindParam(':price', $this->price); // Ensure 'price' property is set
    $query->bindParam(':product_id', $this->product_id); // Fix the property name to 'product_id'

    // Execute the query
    return $query->execute();
}

    

}
?>
