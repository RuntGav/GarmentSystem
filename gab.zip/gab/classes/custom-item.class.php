<?php

require_once 'database.class.php';

class CustomItem
{
    public $customer_id = '';
    public $custom_uniform_id = '';
    public $quantity = '';

    protected $db;

    function __construct()
    {
        $this->db = new Database();
    }

    // Insert a new custom uniform into the custom_uniform table
    public function createCustomUniform($data)
    {
        $sql = "INSERT INTO custom_uniform (
                    name, gender, chest_measurement, waist_measurement, hip_measurement,
                    shoulder_width, sleeve_length, pant_length, custom_features, price, production_time_days
                ) VALUES (
                    :name, :gender, :chest_measurement, :waist_measurement, :hip_measurement,
                    :shoulder_width, :sleeve_length, :pant_length, :custom_features, :price, :production_time_days
                )";
        $query = $this->db->connect()->prepare($sql);
        $params = [
            ':name' => $data['name'],
            ':gender' => $data['gender'],
            ':chest_measurement' => $data['chest_measurement'],
            ':waist_measurement' => $data['waist_measurement'],
            ':hip_measurement' => $data['hip_measurement'],
            ':shoulder_width' => $data['shoulder_width'],
            ':sleeve_length' => $data['sleeve_length'],
            ':pant_length' => $data['pant_length'],
            ':custom_features' => $data['custom_features'],
            ':price' => $data['price'] ?? null, // Optional price field
            ':production_time_days' => $data['production_time_days'] ?? null // Optional production time
        ];
        if ($query->execute($params)) {
            return $this->db->connect()->lastInsertId(); // Return the ID of the newly inserted custom uniform
        }
        return false;
    }

    // Add a custom uniform to the cart
    public function addToCartCustom()
    {
        $sql = "INSERT INTO cart (custom_uniform_id, account_id, quantity, status) 
                VALUES (:custom_uniform_id, :customer_id, :quantity, 'pending')";
        $query = $this->db->connect()->prepare($sql);
        return $query->execute([
            ':custom_uniform_id' => $this->custom_uniform_id,
            ':customer_id' => $this->customer_id,
            ':quantity' => $this->quantity,
        ]);
    }

    function showCustomItems() {
        $sql = "SELECT c.cart_id, cu.custom_uniform_id, cu.name AS Custom_Name, cu.gender, cu.price, 
                c.quantity, c.status
                FROM cart c
                LEFT JOIN custom_uniform cu ON c.custom_uniform_id = cu.custom_uniform_id
                WHERE c.account_id = :account_id AND c.product_id IS NULL"; // Exclude regular items
        $query = $this->db->connect()->prepare($sql);
        $query->bindParam(':account_id', $this->customer_id);
        $query->execute();
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    
}
