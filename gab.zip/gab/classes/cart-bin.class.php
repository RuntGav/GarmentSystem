<?php

require_once 'database.class.php';

class CartBin
{
    public $cart_bin_id = '';
    public $cart_id = '';
    public $product_id = '';
    public $custom_uniform_id = '';
    public $account_id = '';
    public $quantity = '';
    public $status = '';
    public $deleted_at = '';

    protected $db;

    function __construct()
    {
        $this->db = new Database();
    }

    function showAll($search = '', $status = '') {
        $sql = "SELECT cb.*, 
                       p.name AS product_name, 
                       cu.name AS custom_uniform_name, 
                       c.username AS customer_name -- Use username as customer name
                FROM cart_bin cb
                LEFT JOIN product p ON cb.product_id = p.product_id
                LEFT JOIN custom_uniform cu ON cb.custom_uniform_id = cu.custom_uniform_id
                LEFT JOIN Account c ON cb.account_id = c.id -- Correct column name for Account table
                WHERE (p.name LIKE CONCAT('%', :search, '%') 
                       OR cu.name LIKE CONCAT('%', :search, '%') 
                       OR c.username LIKE CONCAT('%', :search, '%')) -- Search by username
                  AND (:status = '' OR cb.status = :status)
                ORDER BY cb.deleted_at DESC;";
        $query = $this->db->connect()->prepare($sql);
        $query->bindParam(':search', $search);
        $query->bindParam(':status', $status);
        $data = null;
        if ($query->execute()) {
            $data = $query->fetchAll(PDO::FETCH_ASSOC);
        }
        return $data;
    }
    
    
    
    
    

    function restore($cart_bin_id)
{
    try {
        // Begin transaction
        $this->db->connect()->beginTransaction();

        // Retrieve the cart bin item details
        $sql = "SELECT * FROM cart_bin WHERE cart_bin_id = :cart_bin_id";
        $query = $this->db->connect()->prepare($sql);
        $query->execute([':cart_bin_id' => $cart_bin_id]);
        $cartBinItem = $query->fetch(PDO::FETCH_ASSOC);

        if (!$cartBinItem) {
            throw new Exception("Cart bin item not found.");
        }

        // Insert the item back into the cart table
        $sql = "INSERT INTO cart (
                    cart_id, product_id, custom_uniform_id, account_id, quantity, status, created_at, updated_at
                ) VALUES (
                    :cart_id, :product_id, :custom_uniform_id, :account_id, :quantity, :status, :created_at, :updated_at
                )";
        $query = $this->db->connect()->prepare($sql);
        $query->execute([
            ':cart_id' => $cartBinItem['cart_id'],
            ':product_id' => $cartBinItem['product_id'],
            ':custom_uniform_id' => $cartBinItem['custom_uniform_id'],
            ':account_id' => $cartBinItem['account_id'],
            ':quantity' => $cartBinItem['quantity'],
            ':status' => $cartBinItem['status'],
            ':created_at' => $cartBinItem['created_at'],
            ':updated_at' => $cartBinItem['updated_at'],
        ]);

        // Delete the item from the cart_bin table
        $sql = "DELETE FROM cart_bin WHERE cart_bin_id = :cart_bin_id";
        $query = $this->db->connect()->prepare($sql);
        $query->execute([':cart_bin_id' => $cart_bin_id]);

        // Commit transaction
        $this->db->connect()->commit();

        return true;
    } catch (Exception $e) {
        // Rollback transaction in case of an error
        $this->db->connect()->rollBack();
        error_log($e->getMessage());
        return false;
    }
}


    function deletePermanently($cart_bin_id)
    {
        $sql = "DELETE FROM cart_bin WHERE cart_bin_id = :cart_bin_id;";
        $query = $this->db->connect()->prepare($sql);
        $query->bindParam(':cart_bin_id', $cart_bin_id);
        return $query->execute();
    }
}
